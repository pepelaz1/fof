window.local_table1_136_data = [
{
 csv: "Classification, Name\u000AClass:, Actinopterygii\u000AOrder:, Anguilliformes\u000AFamily:, Congridae\u000ASpecies:, Conger conger ",
 first: "congerOnePageHtm_htm_files/23127.png",
 firstdark: "congerOnePageHtm_htm_files/23128.png",
 last: "congerOnePageHtm_htm_files/23129.png",
 lastdark: "congerOnePageHtm_htm_files/23130.png",
 next: "congerOnePageHtm_htm_files/23131.png",
 nextdark: "congerOnePageHtm_htm_files/23132.png",
 prev: "congerOnePageHtm_htm_files/23133.png",
 prevdark: "congerOnePageHtm_htm_files/23134.png",
 rows: "5",
 theme: "1"
}
];
