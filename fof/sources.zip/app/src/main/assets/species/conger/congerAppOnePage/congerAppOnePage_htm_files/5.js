window.local_table1_138_data = [
{
 csv: "Conger, Boat, Shore\u000Albs:, 133 04 00, 68 08 00\u000Akilos:, 60.442, 31.072\u000AYear:, 1995, 1992\u000ABy:, V. Evans, M. Larkin\u000APlace:, Berry Head, Devil\u2019s Point",
 first: "congerOnePageHtm_htm_files/23127.png",
 firstdark: "congerOnePageHtm_htm_files/23128.png",
 last: "congerOnePageHtm_htm_files/23129.png",
 lastdark: "congerOnePageHtm_htm_files/23130.png",
 next: "congerOnePageHtm_htm_files/23131.png",
 nextdark: "congerOnePageHtm_htm_files/23132.png",
 prev: "congerOnePageHtm_htm_files/23133.png",
 prevdark: "congerOnePageHtm_htm_files/23134.png",
 rows: "6",
 theme: "1"
}
];
