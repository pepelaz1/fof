window.local_table1_18_data = [
{
 csv: "Line, Main, Trace\u000AType:, Mono, Wire\u000AStrength (lbs):, 30/50, 80\u000ALength (mts):, - , 1\u000AHook size:, 6/0, 8/0",
 first: "congerOnePageHtm_htm_files/23127.png",
 firstdark: "congerOnePageHtm_htm_files/23128.png",
 last: "congerOnePageHtm_htm_files/23129.png",
 lastdark: "congerOnePageHtm_htm_files/23130.png",
 next: "congerOnePageHtm_htm_files/23131.png",
 nextdark: "congerOnePageHtm_htm_files/23132.png",
 prev: "congerOnePageHtm_htm_files/23133.png",
 prevdark: "congerOnePageHtm_htm_files/23134.png",
 rows: "5",
 theme: "1"
}
];
