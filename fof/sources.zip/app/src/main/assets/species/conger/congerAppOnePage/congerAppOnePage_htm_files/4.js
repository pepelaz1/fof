window.local_table1_137_data = [
{
 csv: "Rig, Rod, Reel\u000A1: Leger: Running - Rotten bottom, 50 lbs Roller guides, Multiplier\u000A2: Leger: Rolling - Swivel hook, 50 lbs Roller guides, Multiplier",
 first: "congerOnePageHtm_htm_files/23127.png",
 firstdark: "congerOnePageHtm_htm_files/23128.png",
 last: "congerOnePageHtm_htm_files/23129.png",
 lastdark: "congerOnePageHtm_htm_files/23130.png",
 next: "congerOnePageHtm_htm_files/23131.png",
 nextdark: "congerOnePageHtm_htm_files/23132.png",
 prev: "congerOnePageHtm_htm_files/23133.png",
 prevdark: "congerOnePageHtm_htm_files/23134.png",
 rows: "3",
 theme: "1"
}
];
