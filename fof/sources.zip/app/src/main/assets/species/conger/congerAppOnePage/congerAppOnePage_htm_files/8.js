window.local_table1_13_data = [
{
 csv: "Natural Food, Bait, Presentation\u000ACrab, Crab, Whole\u000ACuttle, Cuttle, Whole\u000APout, Pout, Whole\u000A-,Mackerel, Large lask\u000ASquid, Squid, Whole",
 first: "congerOnePageHtm_htm_files/23127.png",
 firstdark: "congerOnePageHtm_htm_files/23128.png",
 last: "congerOnePageHtm_htm_files/23129.png",
 lastdark: "congerOnePageHtm_htm_files/23130.png",
 next: "congerOnePageHtm_htm_files/23131.png",
 nextdark: "congerOnePageHtm_htm_files/23132.png",
 prev: "congerOnePageHtm_htm_files/23133.png",
 prevdark: "congerOnePageHtm_htm_files/23134.png",
 rows: "6",
 theme: "1"
}
];
