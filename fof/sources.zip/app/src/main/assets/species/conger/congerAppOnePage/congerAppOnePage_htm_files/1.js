window.local_table1_135_data = [
{
 csv: "Organisation, Landing Size cms, Size Sexual Maturity\u000AEuropean Union:, None, Unknown\u000AICFA:, 58 - Restrictions, -\u000AAngling Trust (Boat), 120, -\u000AAngling Trust (Shore), 91, -",
 first: "congerOnePageHtm_htm_files/23127.png",
 firstdark: "congerOnePageHtm_htm_files/23128.png",
 last: "congerOnePageHtm_htm_files/23129.png",
 lastdark: "congerOnePageHtm_htm_files/23130.png",
 next: "congerOnePageHtm_htm_files/23131.png",
 nextdark: "congerOnePageHtm_htm_files/23132.png",
 prev: "congerOnePageHtm_htm_files/23133.png",
 prevdark: "congerOnePageHtm_htm_files/23134.png",
 rows: "8",
 theme: "1"
}
];
