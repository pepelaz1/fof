window.local_table1_227_data = [
{
 csv: "Rig, Rod, Reel\u000ALedger: Rolling - Rotten Bottom, Beach Caster, Fixed",
 first: "congerOnePageHtm_htm_files/23121.png",
 firstdark: "congerOnePageHtm_htm_files/23122.png",
 last: "congerOnePageHtm_htm_files/23121.png",
 lastdark: "congerOnePageHtm_htm_files/23122.png",
 next: "congerOnePageHtm_htm_files/23121.png",
 nextdark: "congerOnePageHtm_htm_files/23122.png",
 prev: "congerOnePageHtm_htm_files/23121.png",
 prevdark: "congerOnePageHtm_htm_files/23122.png",
 rows: "2",
 theme: "1"
}
];
