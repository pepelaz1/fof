window.local_table1_457_data = [
{
 csv: "Rig, Rod (lbs), Reel\u000A1. Leger: Rolling - Three Hook & Spoon, 20 - 30, Multiplier\u000A2. Leger: Running - Three Hook, 50, Multiplier\u000A ",
 first: "dabOnePageHtm_htm_files/14470.png",
 firstdark: "dabOnePageHtm_htm_files/14471.png",
 last: "dabOnePageHtm_htm_files/14472.png",
 lastdark: "dabOnePageHtm_htm_files/14473.png",
 next: "dabOnePageHtm_htm_files/14474.png",
 nextdark: "dabOnePageHtm_htm_files/14475.png",
 prev: "dabOnePageHtm_htm_files/14476.png",
 prevdark: "dabOnePageHtm_htm_files/14477.png",
 rows: "3",
 theme: "1"
}
];
