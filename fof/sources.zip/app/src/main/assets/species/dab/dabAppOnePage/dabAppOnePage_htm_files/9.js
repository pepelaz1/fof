window.local_table1_490_data = [
{
 csv: "Classification, Name\u000AClass:, Actinopterygii\u000AOrder:, Pleuronectiformes\u000AFamily:, Pleuronectidae\u000ASpecies:, Limanda limanda",
 first: "dabOnePageHtm_htm_files/14470.png",
 firstdark: "dabOnePageHtm_htm_files/14471.png",
 last: "dabOnePageHtm_htm_files/14472.png",
 lastdark: "dabOnePageHtm_htm_files/14473.png",
 next: "dabOnePageHtm_htm_files/14474.png",
 nextdark: "dabOnePageHtm_htm_files/14475.png",
 prev: "dabOnePageHtm_htm_files/14476.png",
 prevdark: "dabOnePageHtm_htm_files/14477.png",
 rows: "5",
 theme: "1"
}
];
