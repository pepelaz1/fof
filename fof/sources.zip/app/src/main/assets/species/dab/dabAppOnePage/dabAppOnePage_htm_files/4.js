window.local_table1_462_data = [
{
 csv: "Rig,Rod (lbs),Reel\u000A1. Leger: - Running & Breakaway lead, Beach Caster, Fixed spool",
 first: "dabOnePageHtm_htm_files/14462.png",
 firstdark: "dabOnePageHtm_htm_files/14463.png",
 last: "dabOnePageHtm_htm_files/14462.png",
 lastdark: "dabOnePageHtm_htm_files/14463.png",
 next: "dabOnePageHtm_htm_files/14462.png",
 nextdark: "dabOnePageHtm_htm_files/14463.png",
 prev: "dabOnePageHtm_htm_files/14462.png",
 prevdark: "dabOnePageHtm_htm_files/14463.png",
 rows: "2",
 theme: "1"
}
];
