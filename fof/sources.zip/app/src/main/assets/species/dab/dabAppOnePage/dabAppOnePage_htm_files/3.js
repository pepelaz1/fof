window.local_table1_461_data = [
{
 csv: "Line, Main, Trace\u000AType:, Mono, Mono\u000AStrength (lbs):, 10, 10\u000ALength (m):, -, 2\u000AHook Size:, -, 2\u000A  ",
 first: "dabOnePageHtm_htm_files/14470.png",
 firstdark: "dabOnePageHtm_htm_files/14471.png",
 last: "dabOnePageHtm_htm_files/14472.png",
 lastdark: "dabOnePageHtm_htm_files/14473.png",
 next: "dabOnePageHtm_htm_files/14474.png",
 nextdark: "dabOnePageHtm_htm_files/14475.png",
 prev: "dabOnePageHtm_htm_files/14476.png",
 prevdark: "dabOnePageHtm_htm_files/14477.png",
 rows: "5",
 theme: "1"
}
];
