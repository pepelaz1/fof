window.local_table1_486_data = [
{
 csv: "Dab, Boat, Shore\u000Albs:, 02 12 04, 02 09 08\u000Akilos:, 1.254, 1.176\u000AYear:, 1975, 1936\u000ABy:, R. Islip, M. Watts\u000APlace:, Gairlock - Wester Ross, Morfa Beach -Port Talbot",
 first: "dabOnePageHtm_htm_files/14470.png",
 firstdark: "dabOnePageHtm_htm_files/14471.png",
 last: "dabOnePageHtm_htm_files/14472.png",
 lastdark: "dabOnePageHtm_htm_files/14473.png",
 next: "dabOnePageHtm_htm_files/14474.png",
 nextdark: "dabOnePageHtm_htm_files/14475.png",
 prev: "dabOnePageHtm_htm_files/14476.png",
 prevdark: "dabOnePageHtm_htm_files/14477.png",
 rows: "6",
 theme: "1"
}
];
