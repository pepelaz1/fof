window.local_table1_485_data = [
{
 csv: "Natural Food, Bait, Presentation\u000ACrustacean:, Crab, Piece\u000APolychaete Worm:, Ragworm, Small whole\u000AMolluscs:, Limpet, Whole",
 first: "dabOnePageHtm_htm_files/14462.png",
 firstdark: "dabOnePageHtm_htm_files/14463.png",
 last: "dabOnePageHtm_htm_files/14462.png",
 lastdark: "dabOnePageHtm_htm_files/14463.png",
 next: "dabOnePageHtm_htm_files/14462.png",
 nextdark: "dabOnePageHtm_htm_files/14463.png",
 prev: "dabOnePageHtm_htm_files/14462.png",
 prevdark: "dabOnePageHtm_htm_files/14463.png",
 rows: "4",
 theme: "1"
}
];
