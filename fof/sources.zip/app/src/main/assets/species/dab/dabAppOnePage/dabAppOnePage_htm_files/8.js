window.local_table1_487_data = [
{
 csv: "Organisation, Landing Size cms, Size Sexual Maturity\u000AEuropean Union, None,  Unknown\u000AInshore Fisheries and Conservation Authority, 15*, -\u000AAngling Trust (Boat), 23,  -\u000AAngling Trust (Shore),None, -",
 first: "dabOnePageHtm_htm_files/14470.png",
 firstdark: "dabOnePageHtm_htm_files/14471.png",
 last: "dabOnePageHtm_htm_files/14472.png",
 lastdark: "dabOnePageHtm_htm_files/14473.png",
 next: "dabOnePageHtm_htm_files/14474.png",
 nextdark: "dabOnePageHtm_htm_files/14475.png",
 prev: "dabOnePageHtm_htm_files/14476.png",
 prevdark: "dabOnePageHtm_htm_files/14477.png",
 rows: "5",
 theme: "1"
}
];
