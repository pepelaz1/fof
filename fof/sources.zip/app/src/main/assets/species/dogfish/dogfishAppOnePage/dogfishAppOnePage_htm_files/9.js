window.local_table1_527_data = [
{
 csv: "Organisation, Landing Size (cms), Size Sexual Maturity\u000AEuropean Union, None,  60\u000AInshore Fisheries and Conservation Authority, None, -\u000AAngling Trust (Boat), 46,  -\u000AAngling Trust (Shore), 35, -",
 first: "dogfishOnePageNew_htm_files/36480.png",
 firstdark: "dogfishOnePageNew_htm_files/36481.png",
 last: "dogfishOnePageNew_htm_files/36482.png",
 lastdark: "dogfishOnePageNew_htm_files/36483.png",
 next: "dogfishOnePageNew_htm_files/36484.png",
 nextdark: "dogfishOnePageNew_htm_files/36485.png",
 prev: "dogfishOnePageNew_htm_files/36486.png",
 prevdark: "dogfishOnePageNew_htm_files/36487.png",
 rows: "5",
 theme: "1"
}
];
