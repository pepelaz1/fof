window.local_table1_520_data = [
{
 csv: "Natural Food, Bait, Presentation\u000ACrustaceans, Crab, Piece\u000AMolluscs, Limpet or Whelk, Whole\u000APolychaete worms, Rag or Lug, Whole\u000ASmall fishes, Mackerel, Large lask\u000A- , Squid, Whole",
 first: "dogfishOnePageNew_htm_files/36477.png",
 firstdark: "dogfishOnePageNew_htm_files/36478.png",
 last: "dogfishOnePageNew_htm_files/36477.png",
 lastdark: "dogfishOnePageNew_htm_files/36478.png",
 next: "dogfishOnePageNew_htm_files/36477.png",
 nextdark: "dogfishOnePageNew_htm_files/36478.png",
 prev: "dogfishOnePageNew_htm_files/36477.png",
 prevdark: "dogfishOnePageNew_htm_files/36478.png",
 rows: "6",
 theme: "1"
}
];
