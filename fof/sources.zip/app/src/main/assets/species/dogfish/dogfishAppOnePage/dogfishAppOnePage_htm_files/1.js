window.local_table1_500_data = [
{
 csv: "Rig,Rod (lbs),Reel\u000A1. Leger - Running, Beach Caster, Fixed spool",
 first: "dogfishOnePageNew_htm_files/36477.png",
 firstdark: "dogfishOnePageNew_htm_files/36478.png",
 last: "dogfishOnePageNew_htm_files/36477.png",
 lastdark: "dogfishOnePageNew_htm_files/36478.png",
 next: "dogfishOnePageNew_htm_files/36477.png",
 nextdark: "dogfishOnePageNew_htm_files/36478.png",
 prev: "dogfishOnePageNew_htm_files/36477.png",
 prevdark: "dogfishOnePageNew_htm_files/36478.png",
 rows: "2",
 theme: "1"
}
];
