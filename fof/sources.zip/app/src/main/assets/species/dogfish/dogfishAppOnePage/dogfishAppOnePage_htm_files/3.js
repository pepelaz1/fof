window.local_table1_449_data = [
{
 csv: "Rig, Rod (lbs), Reel\u000A1. Leger - Running Rotten bottom,10 - 12, Multiplier\u000A2. Leger - Running, 10 - 12, Multiplier\u000A ",
 first: "dogfishOnePageNew_htm_files/36480.png",
 firstdark: "dogfishOnePageNew_htm_files/36481.png",
 last: "dogfishOnePageNew_htm_files/36482.png",
 lastdark: "dogfishOnePageNew_htm_files/36483.png",
 next: "dogfishOnePageNew_htm_files/36484.png",
 nextdark: "dogfishOnePageNew_htm_files/36485.png",
 prev: "dogfishOnePageNew_htm_files/36486.png",
 prevdark: "dogfishOnePageNew_htm_files/36487.png",
 rows: "3",
 theme: "1"
}
];
