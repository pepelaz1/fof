window.local_table1_457_data = [
{
 csv: "Line, Main, Trace\u000AType:, Mono, Mono\u000AStrength (lbs):, 20, 15\u000ALength (m):, -, 2\u000AHook Size:, -, 4/0\u000A  ",
 first: "dogfishOnePageNew_htm_files/36480.png",
 firstdark: "dogfishOnePageNew_htm_files/36481.png",
 last: "dogfishOnePageNew_htm_files/36482.png",
 lastdark: "dogfishOnePageNew_htm_files/36483.png",
 next: "dogfishOnePageNew_htm_files/36484.png",
 nextdark: "dogfishOnePageNew_htm_files/36485.png",
 prev: "dogfishOnePageNew_htm_files/36486.png",
 prevdark: "dogfishOnePageNew_htm_files/36487.png",
 rows: "5",
 theme: "1"
}
];
