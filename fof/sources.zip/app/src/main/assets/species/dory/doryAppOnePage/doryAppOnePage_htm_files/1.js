window.local_table1_255_data = [
{
 csv: "Rig,Rod,Reel\u000AN/A,N/A,N/A",
 first: "doryOnePageHtm_htm_files/14462.png",
 firstdark: "doryOnePageHtm_htm_files/14463.png",
 last: "doryOnePageHtm_htm_files/14462.png",
 lastdark: "doryOnePageHtm_htm_files/14463.png",
 next: "doryOnePageHtm_htm_files/14462.png",
 nextdark: "doryOnePageHtm_htm_files/14463.png",
 prev: "doryOnePageHtm_htm_files/14462.png",
 prevdark: "doryOnePageHtm_htm_files/14463.png",
 rows: "2",
 theme: "1"
}
];
