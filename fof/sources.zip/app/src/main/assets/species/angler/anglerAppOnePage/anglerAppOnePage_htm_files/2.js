window.local_table1_252_data = [
{
 csv: "Line, Main, Trace\u000AType:,Mono,Wire\u000AStrength (lbs):,20/40,60\u000ALength (mts):,n/a,1\u000AHook Size:,-,6/0 ",
 first: "anglerAppOnePage_htm_files/14462.png",
 firstdark: "anglerAppOnePage_htm_files/14463.png",
 last: "anglerAppOnePage_htm_files/14462.png",
 lastdark: "anglerAppOnePage_htm_files/14463.png",
 next: "anglerAppOnePage_htm_files/14462.png",
 nextdark: "anglerAppOnePage_htm_files/14463.png",
 prev: "anglerAppOnePage_htm_files/14462.png",
 prevdark: "anglerAppOnePage_htm_files/14463.png",
 rows: "5",
 theme: "1"
}
];
