window.local_table1_250_data = [
{
 csv: "Natural Food, Bait, Presentation\u000ACrab,Crab,Whole\u000APout,Mackerel,Large lask\u000ASandeel,Sandeel,Whole\u000AFlatfish,Dab,Whole\u000ASquid,Squid,Whole",
 first: "anglerAppOnePage_htm_files/14462.png",
 firstdark: "anglerAppOnePage_htm_files/14463.png",
 last: "anglerAppOnePage_htm_files/14462.png",
 lastdark: "anglerAppOnePage_htm_files/14463.png",
 next: "anglerAppOnePage_htm_files/14462.png",
 nextdark: "anglerAppOnePage_htm_files/14463.png",
 prev: "anglerAppOnePage_htm_files/14462.png",
 prevdark: "anglerAppOnePage_htm_files/14463.png",
 rows: "6",
 theme: "1"
}
];
