window.local_table1_164_data = [
{
 csv: "Rig, Rod, Reel\u000A1: Leger-Running, 20lbs, Multiplier\u000A2: Leger-Rolling with Spoon, 20lbs, Multiplier",
 first: "anglerAppOnePage_htm_files/14470.png",
 firstdark: "anglerAppOnePage_htm_files/14471.png",
 last: "anglerAppOnePage_htm_files/14472.png",
 lastdark: "anglerAppOnePage_htm_files/14473.png",
 next: "anglerAppOnePage_htm_files/14474.png",
 nextdark: "anglerAppOnePage_htm_files/14475.png",
 prev: "anglerAppOnePage_htm_files/14476.png",
 prevdark: "anglerAppOnePage_htm_files/14477.png",
 rows: "3",
 theme: "1"
}
];
