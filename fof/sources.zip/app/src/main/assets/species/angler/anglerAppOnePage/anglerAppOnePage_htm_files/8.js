window.local_table1_165_data = [
{
 csv: "Angler,Boat,Shore\u000Albs,94 12 04,68 02 00\u000AKilos,42.985,30.899\u000AYear:,1985,1967\u000ABy:,S.Neill,H.Legerton\u000APlace:,Belfast Lough,Canvey Island",
 first: "anglerAppOnePage_htm_files/14470.png",
 firstdark: "anglerAppOnePage_htm_files/14471.png",
 last: "anglerAppOnePage_htm_files/14472.png",
 lastdark: "anglerAppOnePage_htm_files/14473.png",
 next: "anglerAppOnePage_htm_files/14474.png",
 nextdark: "anglerAppOnePage_htm_files/14475.png",
 prev: "anglerAppOnePage_htm_files/14476.png",
 prevdark: "anglerAppOnePage_htm_files/14477.png",
 rows: "6",
 theme: "1"
}
];
