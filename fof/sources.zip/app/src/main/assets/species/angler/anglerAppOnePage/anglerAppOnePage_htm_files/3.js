window.local_table1_162_data = [
{
 csv: "Organisation, Landing Size cms, Size Sexual Maturity\u000AEuropean Union, None, -\u000AInshore Fisheries and Conservation Authority, None, -\u000AAngling Trust (Boat), None, -\u000AAngling Trust (Shore), None, -",
 first: "anglerAppOnePage_htm_files/14470.png",
 firstdark: "anglerAppOnePage_htm_files/14471.png",
 last: "anglerAppOnePage_htm_files/14472.png",
 lastdark: "anglerAppOnePage_htm_files/14473.png",
 next: "anglerAppOnePage_htm_files/14474.png",
 nextdark: "anglerAppOnePage_htm_files/14475.png",
 prev: "anglerAppOnePage_htm_files/14476.png",
 prevdark: "anglerAppOnePage_htm_files/14477.png",
 rows: "8",
 theme: "1"
}
];
