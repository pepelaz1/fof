window.local_table1_255_data = [
{
 csv: "Rig,Rod,Reel\u000AN/A,N/A,N/A",
 first: "anglerAppOnePage_htm_files/14462.png",
 firstdark: "anglerAppOnePage_htm_files/14463.png",
 last: "anglerAppOnePage_htm_files/14462.png",
 lastdark: "anglerAppOnePage_htm_files/14463.png",
 next: "anglerAppOnePage_htm_files/14462.png",
 nextdark: "anglerAppOnePage_htm_files/14463.png",
 prev: "anglerAppOnePage_htm_files/14462.png",
 prevdark: "anglerAppOnePage_htm_files/14463.png",
 rows: "2",
 theme: "1"
}
];
