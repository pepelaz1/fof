window.local_table1_528_data = [
{
 csv: "Natural Food, Bait, Presentation\u000ACrustaceans:, Crab, Peeler\u000AMolluscs:, Limpet, Whole\u000AWorms:, Lug / Rag, Whole/Bunch\u000A , Squid, Sliver\u000A , Mackerel, Sliver",
 first: "breamOnePageNew_htm_files/14470.png",
 firstdark: "breamOnePageNew_htm_files/14471.png",
 last: "breamOnePageNew_htm_files/14472.png",
 lastdark: "breamOnePageNew_htm_files/14473.png",
 next: "breamOnePageNew_htm_files/14474.png",
 nextdark: "breamOnePageNew_htm_files/14475.png",
 prev: "breamOnePageNew_htm_files/14476.png",
 prevdark: "breamOnePageNew_htm_files/14477.png",
 rows: "6",
 theme: "1"
}
];
