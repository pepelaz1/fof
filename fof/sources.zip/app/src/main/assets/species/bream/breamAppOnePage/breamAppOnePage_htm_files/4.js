window.local_table1_511_data = [
{
 csv: "Line, Main, Trace\u000AType:, Mono, Mono\u000AStrength (lbs):, 10/15, 10\u000ALength (m):, -, 2 - 3\u000AHook Size:, -, 2 - 6",
 first: "breamOnePageNew_htm_files/14470.png",
 firstdark: "breamOnePageNew_htm_files/14471.png",
 last: "breamOnePageNew_htm_files/14472.png",
 lastdark: "breamOnePageNew_htm_files/14473.png",
 next: "breamOnePageNew_htm_files/14474.png",
 nextdark: "breamOnePageNew_htm_files/14475.png",
 prev: "breamOnePageNew_htm_files/14476.png",
 prevdark: "breamOnePageNew_htm_files/14477.png",
 rows: "6",
 theme: "1"
}
];
