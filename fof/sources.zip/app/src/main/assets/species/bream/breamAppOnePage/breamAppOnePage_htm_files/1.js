window.local_table1_296_data = [
{
 csv: "Rig,Rod,Reel\u000AN/A,N/A,N/A",
 first: "breamOnePageNew_htm_files/36303.png",
 firstdark: "breamOnePageNew_htm_files/36304.png",
 last: "breamOnePageNew_htm_files/36303.png",
 lastdark: "breamOnePageNew_htm_files/36304.png",
 next: "breamOnePageNew_htm_files/36303.png",
 nextdark: "breamOnePageNew_htm_files/36304.png",
 prev: "breamOnePageNew_htm_files/36303.png",
 prevdark: "breamOnePageNew_htm_files/36304.png",
 rows: "2",
 theme: "1"
}
];
