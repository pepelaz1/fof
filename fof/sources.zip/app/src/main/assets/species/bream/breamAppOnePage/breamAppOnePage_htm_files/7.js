window.local_table1_529_data = [
{
 csv: "Bream - Black, Boat, Shore\u000Albs:, 06 14 04, 06 08 06\u000Akilos:, 3.125, 2.959\u000AYear:, 1977, 2001\u000ABy:, J. Garlick, R. Guille\u000APlace:, Wreck off Torquay, Creux Harbour - Sark",
 first: "breamOnePageNew_htm_files/14470.png",
 firstdark: "breamOnePageNew_htm_files/14471.png",
 last: "breamOnePageNew_htm_files/14472.png",
 lastdark: "breamOnePageNew_htm_files/14473.png",
 next: "breamOnePageNew_htm_files/14474.png",
 nextdark: "breamOnePageNew_htm_files/14475.png",
 prev: "breamOnePageNew_htm_files/14476.png",
 prevdark: "breamOnePageNew_htm_files/14477.png",
 rows: "6",
 theme: "1"
}
];
