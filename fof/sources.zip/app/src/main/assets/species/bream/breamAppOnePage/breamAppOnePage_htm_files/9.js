window.local_table1_534_data = [
{
 csv: "Classification, Name\u000AClass:, Actinopterygii\u000AOrder:, Perciformes\u000AFamily:, Sparidae\u000ASpecies:, Spondyliosoma cantharus",
 first: "breamOnePageNew_htm_files/14470.png",
 firstdark: "breamOnePageNew_htm_files/14471.png",
 last: "breamOnePageNew_htm_files/14472.png",
 lastdark: "breamOnePageNew_htm_files/14473.png",
 next: "breamOnePageNew_htm_files/14474.png",
 nextdark: "breamOnePageNew_htm_files/14475.png",
 prev: "breamOnePageNew_htm_files/14476.png",
 prevdark: "breamOnePageNew_htm_files/14477.png",
 rows: "5",
 theme: "1"
}
];
