window.local_table1_531_data = [
{
 csv: "Organisation, Landing Size cms, Size Sexual Maturity\u000AEuropean Union, 23*, 20\u000AInshore Fisheries and Conservation Authority, 23*, -\u000AAngling Trust (Boat), 24*, -\u000AAngling Trust (Shore), 24*, -",
 first: "breamOnePageNew_htm_files/14470.png",
 firstdark: "breamOnePageNew_htm_files/14471.png",
 last: "breamOnePageNew_htm_files/14472.png",
 lastdark: "breamOnePageNew_htm_files/14473.png",
 next: "breamOnePageNew_htm_files/14474.png",
 nextdark: "breamOnePageNew_htm_files/14475.png",
 prev: "breamOnePageNew_htm_files/14476.png",
 prevdark: "breamOnePageNew_htm_files/14477.png",
 rows: "5",
 theme: "1"
}
];
