window.local_table1_514_data = [
{
 csv: "Rig,Rod (lbs),Reel\u000A1. Leger - Running, Beach Caster, Fixed spool",
 first: "codOne%20PageNewHtm_htm_files/36523.png",
 firstdark: "codOne%20PageNewHtm_htm_files/36524.png",
 last: "codOne%20PageNewHtm_htm_files/36523.png",
 lastdark: "codOne%20PageNewHtm_htm_files/36524.png",
 next: "codOne%20PageNewHtm_htm_files/36523.png",
 nextdark: "codOne%20PageNewHtm_htm_files/36524.png",
 prev: "codOne%20PageNewHtm_htm_files/36523.png",
 prevdark: "codOne%20PageNewHtm_htm_files/36524.png",
 rows: "2",
 theme: "1"
}
];
