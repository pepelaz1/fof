window.local_table1_479_data = [
{
 csv: "Rig, Rod (lbs), Reel\u000A1. Leger - Flowing Trace,20/30,Multiplier\u000A2. Pirk & Feathers,50,Multiplier\u000A ",
 first: "codOne%20PageNewHtm_htm_files/14470.png",
 firstdark: "codOne%20PageNewHtm_htm_files/14471.png",
 last: "codOne%20PageNewHtm_htm_files/14472.png",
 lastdark: "codOne%20PageNewHtm_htm_files/14473.png",
 next: "codOne%20PageNewHtm_htm_files/14474.png",
 nextdark: "codOne%20PageNewHtm_htm_files/14475.png",
 prev: "codOne%20PageNewHtm_htm_files/14476.png",
 prevdark: "codOne%20PageNewHtm_htm_files/14477.png",
 rows: "3",
 theme: "1"
}
];
