window.local_table1_516_data = [
{
 csv: "Natural Food, Bait, Presentation\u000ACrustaceans, Crab, Peeler\u000ACrustaceans, Limpet, Whole\u000ASmall fishes, Mackerel, Large lask\u000ASquid, Squid, Whole\u000A-, Worm, Whole + Squid",
 first: "codOne%20PageNewHtm_htm_files/36523.png",
 firstdark: "codOne%20PageNewHtm_htm_files/36524.png",
 last: "codOne%20PageNewHtm_htm_files/36523.png",
 lastdark: "codOne%20PageNewHtm_htm_files/36524.png",
 next: "codOne%20PageNewHtm_htm_files/36523.png",
 nextdark: "codOne%20PageNewHtm_htm_files/36524.png",
 prev: "codOne%20PageNewHtm_htm_files/36523.png",
 prevdark: "codOne%20PageNewHtm_htm_files/36524.png",
 rows: "6",
 theme: "1"
}
];
