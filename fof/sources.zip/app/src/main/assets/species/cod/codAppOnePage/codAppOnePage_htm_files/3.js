window.local_table1_480_data = [
{
 csv: "Line, Main, Trace\u000AType:, Mono, Mono\u000AStrength (lbs):, 20 - 30, 40\u000ALength (m):,  , 1\u000AHook Size:,  , 4/0",
 first: "codOne%20PageNewHtm_htm_files/14470.png",
 firstdark: "codOne%20PageNewHtm_htm_files/14471.png",
 last: "codOne%20PageNewHtm_htm_files/14472.png",
 lastdark: "codOne%20PageNewHtm_htm_files/14473.png",
 next: "codOne%20PageNewHtm_htm_files/14474.png",
 nextdark: "codOne%20PageNewHtm_htm_files/14475.png",
 prev: "codOne%20PageNewHtm_htm_files/14476.png",
 prevdark: "codOne%20PageNewHtm_htm_files/14477.png",
 rows: "5",
 theme: "1"
}
];
