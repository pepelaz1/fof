window.local_table1_519_data = [
{
 csv: "Classification, Name\u000AClass:, Actinopterygii\u000AOrder:, Gadiformes\u000AFamily:, Gadidae\u000ASpecies:, Gadus morhua",
 first: "codOne%20PageNewHtm_htm_files/14470.png",
 firstdark: "codOne%20PageNewHtm_htm_files/14471.png",
 last: "codOne%20PageNewHtm_htm_files/14472.png",
 lastdark: "codOne%20PageNewHtm_htm_files/14473.png",
 next: "codOne%20PageNewHtm_htm_files/14474.png",
 nextdark: "codOne%20PageNewHtm_htm_files/14475.png",
 prev: "codOne%20PageNewHtm_htm_files/14476.png",
 prevdark: "codOne%20PageNewHtm_htm_files/14477.png",
 rows: "5",
 theme: "1"
}
];
