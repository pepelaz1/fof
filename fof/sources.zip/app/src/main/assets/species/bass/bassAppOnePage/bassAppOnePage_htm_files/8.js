window.local_table1_392_data = [
{
 csv: "Bass, Boat, Shore\u000Albs:, 19 09 02, 19 12 00\u000Akilos:, 8.876, 8.958\u000AYear:, 1977, 2012\u000ABy:, P. McEwan, J. Locker\u000APlace:, Hern Bay Kent, Portsmouth Dockyard",
 first: "bassOnePageHtm_htm_files/14470.png",
 firstdark: "bassOnePageHtm_htm_files/14471.png",
 last: "bassOnePageHtm_htm_files/14472.png",
 lastdark: "bassOnePageHtm_htm_files/14473.png",
 next: "bassOnePageHtm_htm_files/14474.png",
 nextdark: "bassOnePageHtm_htm_files/14475.png",
 prev: "bassOnePageHtm_htm_files/14476.png",
 prevdark: "bassOnePageHtm_htm_files/14477.png",
 rows: "6",
 theme: "1"
}
];
