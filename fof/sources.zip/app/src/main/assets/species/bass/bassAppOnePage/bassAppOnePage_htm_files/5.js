window.local_table1_383_data = [
{
 csv: "Rig,Rod,Reel\u000APennel,Beach Caster, Fixed",
 first: "bassOnePageHtm_htm_files/23290.png",
 firstdark: "bassOnePageHtm_htm_files/23291.png",
 last: "bassOnePageHtm_htm_files/23290.png",
 lastdark: "bassOnePageHtm_htm_files/23291.png",
 next: "bassOnePageHtm_htm_files/23290.png",
 nextdark: "bassOnePageHtm_htm_files/23291.png",
 prev: "bassOnePageHtm_htm_files/23290.png",
 prevdark: "bassOnePageHtm_htm_files/23291.png",
 rows: "2",
 theme: "1"
}
];
