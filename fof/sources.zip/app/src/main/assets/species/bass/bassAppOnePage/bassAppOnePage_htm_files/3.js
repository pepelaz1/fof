window.local_table1_6_data = [
{
 csv: "Line, Main, Trace\u000A Type:, Mono, -\u000AStrength (lbs):, 20, -\u000ALength (mts):, Varies, -\u000AHook:, 4/0 / 6/0, -",
 first: "bassOnePageHtm_htm_files/14470.png",
 firstdark: "bassOnePageHtm_htm_files/14471.png",
 last: "bassOnePageHtm_htm_files/14472.png",
 lastdark: "bassOnePageHtm_htm_files/14473.png",
 next: "bassOnePageHtm_htm_files/14474.png",
 nextdark: "bassOnePageHtm_htm_files/14475.png",
 prev: "bassOnePageHtm_htm_files/14476.png",
 prevdark: "bassOnePageHtm_htm_files/14477.png",
 rows: "6",
 theme: "0"
}
];
