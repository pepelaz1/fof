window.local_table1_244_data = [
{
 csv: "Angler,Boat,Shore\u000Albs,94 12 04,68 02 00\u000AKilos,42.985,30.899\u000AYear:,1985,1967\u000ABy:,S.Neill,H.Legerton\u000APlace:,Belfast Lough,Canvey Island",
 first: "bassOnePageHtm_htm_files/14470.png",
 firstdark: "bassOnePageHtm_htm_files/14471.png",
 last: "bassOnePageHtm_htm_files/14472.png",
 lastdark: "bassOnePageHtm_htm_files/14473.png",
 next: "bassOnePageHtm_htm_files/14474.png",
 nextdark: "bassOnePageHtm_htm_files/14475.png",
 prev: "bassOnePageHtm_htm_files/14476.png",
 prevdark: "bassOnePageHtm_htm_files/14477.png",
 rows: "6",
 theme: "1"
}
];
