window.local_table1_389_data = [
{
 csv: "Natural Food, Bait, Presentation\u000ACrustaceans, Crab, Peeler\u000ACrustaceans, Limpet, Whole\u000ACrustaceans, Shrimp, Bunch\u000ASmall fishes, Sandeel, Trolling\u000ASmall fishes, Pout, Sink & Draw\u000ASmall fishes, Mackelel, Large lask\u000ASquid, Squid, Whole\u000A-, Worm, Whole + Squid",
 first: "bassOnePageHtm_htm_files/23290.png",
 firstdark: "bassOnePageHtm_htm_files/23291.png",
 last: "bassOnePageHtm_htm_files/23290.png",
 lastdark: "bassOnePageHtm_htm_files/23291.png",
 next: "bassOnePageHtm_htm_files/23290.png",
 nextdark: "bassOnePageHtm_htm_files/23291.png",
 prev: "bassOnePageHtm_htm_files/23290.png",
 prevdark: "bassOnePageHtm_htm_files/23291.png",
 rows: "9",
 theme: "1"
}
];
