window.local_table1_386_data = [
{
 csv: "Line, Main, Trace\u000AType:,Mono,Mono\u000AStrength (lbs):,10 - 18,18\u000ALength (mts):,-,3\u000AHook:,Size,6/0 ",
 first: "bassOnePageHtm_htm_files/23290.png",
 firstdark: "bassOnePageHtm_htm_files/23291.png",
 last: "bassOnePageHtm_htm_files/23290.png",
 lastdark: "bassOnePageHtm_htm_files/23291.png",
 next: "bassOnePageHtm_htm_files/23290.png",
 nextdark: "bassOnePageHtm_htm_files/23291.png",
 prev: "bassOnePageHtm_htm_files/23290.png",
 prevdark: "bassOnePageHtm_htm_files/23291.png",
 rows: "5",
 theme: "1"
}
];
