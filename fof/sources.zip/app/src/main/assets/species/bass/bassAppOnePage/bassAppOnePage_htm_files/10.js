window.local_table1_398_data = [
{
 csv: "Classification,Name\u000AClass:, Actinopterygii\u000AOrder:,Perciformes\u000AFamily:,Moronidae\u000ASpecies:,Dicentrarchus labrax ",
 first: "bassOnePageHtm_htm_files/14470.png",
 firstdark: "bassOnePageHtm_htm_files/14471.png",
 last: "bassOnePageHtm_htm_files/14472.png",
 lastdark: "bassOnePageHtm_htm_files/14473.png",
 next: "bassOnePageHtm_htm_files/14474.png",
 nextdark: "bassOnePageHtm_htm_files/14475.png",
 prev: "bassOnePageHtm_htm_files/14476.png",
 prevdark: "bassOnePageHtm_htm_files/14477.png",
 rows: "5",
 theme: "1"
}
];
