window.local_table1_28_data = [
{
 csv: "Size, lbs, kilo\u000A10, 50, 20\u000A7, 65, 30\u000A5, 100, 45\u000A3, 125, 60\u000A1, 150, 70\u000A1/0, 200, 90\u000A2/0, 250, 110\u000A3/0, 300, 140\u000A4/0, 350, 160\u000A5/0, 400, 180 ",
 first: "swivelHtm_htm_files/14470.png",
 firstdark: "swivelHtm_htm_files/14471.png",
 last: "swivelHtm_htm_files/14472.png",
 lastdark: "swivelHtm_htm_files/14473.png",
 next: "swivelHtm_htm_files/14474.png",
 nextdark: "swivelHtm_htm_files/14475.png",
 prev: "swivelHtm_htm_files/14476.png",
 prevdark: "swivelHtm_htm_files/14477.png",
 rows: "11",
 theme: "1"
}
];
